function enviarFormulario() {
  var nombres = document.getElementById("nombres").value;
  var apellidos = document.getElementById("apellidos").value;
  var email = document.getElementById("email").value;

  // Validar los datos aquí si es necesario
  
  
  // Redirigir al Landing Page
  window.location.href = "lading.html";
}
